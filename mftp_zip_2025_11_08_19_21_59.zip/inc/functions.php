<?php
function cc_env(){ static $cfg=null; if($cfg===null){ $cfg=include __DIR__.'/../config.php'; } return $cfg; }

function cc_boot_session(){
  if(session_status()===PHP_SESSION_ACTIVE) return;
  $cfg = cc_env();
  if(!empty($cfg['session_save_path'])){ @session_save_path($cfg['session_save_path']); }
  $is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') == 443);
  $params = session_get_cookie_params();
  session_set_cookie_params([
    'lifetime' => 0,
    'path' => $params['path'] ?? '/',
    'domain' => $params['domain'] ?? '',
    'secure' => $is_https,
    'httponly' => true,
    'samesite' => 'Lax'
  ]);
  session_name('cc_portal');
  @session_start();
}

function cc_csrf_token(){
  cc_boot_session();
  if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
  return $_SESSION['csrf'];
}

function cc_csrf_check(){
  cc_boot_session();
  $sent = $_POST['csrf'] ?? '';
  $real = $_SESSION['csrf'] ?? '';
  if (empty($sent) || empty($real) || !hash_equals($real, $sent)) {
    http_response_code(400);
    exit('Invalid CSRF token.');
  }
}

function cc_flash($msg){ cc_boot_session(); $_SESSION['flash']=$msg; }
function cc_flash_render(){ cc_boot_session(); if(!empty($_SESSION['flash'])){ $msg=$_SESSION['flash']; $cls=(strpos($msg,'✅')===0)?'alert success flash':'alert flash'; echo '<div class="'.$cls.'">'.htmlspecialchars($msg).'</div>'; unset($_SESSION['flash']); } }
function cc_sanitize_filename($name){ return preg_replace('/[^A-Za-z0-9._-]/', '_', $name); }
?>

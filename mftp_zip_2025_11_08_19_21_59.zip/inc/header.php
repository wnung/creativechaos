<?php require_once __DIR__.'/functions.php'; cc_boot_session(); $cfg=cc_env(); header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0'); header('Pragma: no-cache'); ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Creative Chaos • Writing Competition</title>
<meta name="description" content="Register teams or open class writers, upload entries, and manage the Creative Chaos writing competition.">
<meta name="theme-color" content="#0c1222">
<link rel="icon" href="<?=$cfg['app_url']?>/assets/logo.svg" type="image/svg+xml">
<link rel="stylesheet" href="<?=$cfg['app_url']?>/assets/styles.css">
<script defer src="<?=$cfg['app_url']?>/assets/script.js"></script>
  <link rel="stylesheet" href="/assets/css/cc-theme.css">
</head>
<body>
<div class="header-wrap">
  <nav class="nav container" aria-label="Main">
    <div class="brand">
      <img src="<?=$cfg['app_url']?>/assets/logo.svg" alt="" aria-hidden="true">
      <h1>Creative Chaos • Writing Competition</h1>
    </div>
    <div class="menu" role="navigation">
      <a href="<?=$cfg['app_url']?>/">Home</a>
      <a href="<?=$cfg['app_url']?>/register.php">Registration</a>
      <a href="<?=$cfg['app_url']?>/submit.php">Submit Entry</a>
      <a href="<?=$cfg['app_url']?>/author_signup.php">Author Showcase</a>
      <a href="<?=$cfg['app_url']?>/admin/login.php" class="badge">Admin</a>
    </div>
  </nav>
</div>
<div class="container">
<?php cc_flash_render(); ?>

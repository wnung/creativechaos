<?php
if(session_status()!==PHP_SESSION_ACTIVE) session_start();
require_once __DIR__.'/db.php';
function cc_is_logged_in(){ return !empty($_SESSION['admin_id']); }
function cc_require_login(){ if(!cc_is_logged_in()){ header('Location: login.php'); exit; } }
function cc_admin(){ return ['id'=>$_SESSION['admin_id']??null,'email'=>$_SESSION['admin_email']??null,'role'=>$_SESSION['admin_role']??'staff']; }
function cc_is_super(){ return (cc_admin()['role'] ?? 'staff') === 'super'; }
function cc_login($email,$password){
  $pdo=cc_db(); $st=$pdo->prepare("SELECT * FROM admins WHERE email=? LIMIT 1"); $st->execute([$email]); $r=$st->fetch();
  if($r && (int)$r['is_active']===1 && password_verify($password,$r['password_hash'])){ $_SESSION['admin_id']=$r['id']; $_SESSION['admin_email']=$r['email']; $_SESSION['admin_role']=$r['role'] ?? 'staff'; return true; }
  return false;
}
function cc_logout(){ session_destroy(); }
?>

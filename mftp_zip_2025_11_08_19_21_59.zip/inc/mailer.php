<?php
require_once __DIR__.'/functions.php';
require_once __DIR__.'/db.php';

function cc_send_mail($to, $subject, $html){
  $cfg = cc_env();
  $from_email = $cfg['smtp']['from_email'] ?? 'noreply@localhost';
  $from_name  = $cfg['smtp']['from_name'] ?? 'Creative Chaos';
  $headers  = "MIME-Version: 1.0\r\n";
  $headers .= "Content-type: text/html; charset=UTF-8\r\n";
  $headers .= "From: ".sprintf('"%s" <%s>', $from_name, $from_email)."\r\n";
  // Basic mail(); for robust delivery, configure DreamHost mail or SMTP relay.
  @mail($to, $subject, $html, $headers);
}

function cc_notify_registration($reg_id){
  $pdo = cc_db();
  $r = $pdo->prepare("SELECT * FROM registrations WHERE id=?");
  $r->execute([$reg_id]);
  $reg = $r->fetch();
  if(!$reg) return;

  // Build summary
  $type = strtoupper($reg['registration_type']);
  $summary = "<p><strong>Type:</strong> {$type}<br>";
  if($reg['registration_type']==='team'){
    $summary .= "<strong>Team:</strong> ".htmlspecialchars($reg['team_name'])."<br>";
    $summary .= "<strong>School:</strong> ".htmlspecialchars($reg['school'])."<br>";
    $summary .= "<strong>Contact:</strong> ".htmlspecialchars($reg['guardian_email'])."<br>";
  } else {
    $summary .= "<strong>Contact (first registrant):</strong> ".htmlspecialchars($reg['guardian_email'])."<br>";
  }
  $summary .= "<strong>Writers:</strong> ".(int)$reg['writer_count']."<br>";
  if($reg['registration_type']==='team'){
    $summary .= "<strong>Extra Writers:</strong> ".(int)$reg['extra_writers']."<br>";
  }
  $summary .= "<strong>Estimated Fee:</strong> $".number_format((float)$reg['fee'],2)."</p>
<?php
  // Append writer list
  $writersHtml = '';
  $wq = $pdo->prepare("SELECT writer_name, writer_email, writer_phone FROM registration_writers WHERE registration_id=? ORDER BY id ASC");
  $wq->execute([$reg_id]);
  $writers = $wq->fetchAll();
  if ($writers) {
    $writersHtml .= '<h4>Writer List</h4><ul>';
    foreach ($writers as $w) {
      if ($reg['registration_type']==='open'){
        $writersHtml .= '<li>'.htmlspecialchars($w['writer_name']).' — ' . htmlspecialchars($w['writer_email']). ' — ' . htmlspecialchars($w['writer_phone']). '</li>';
      } else {
        $writersHtml .= '<li>'.htmlspecialchars($w['writer_name']).'</li>';
      }
    }
    $writersHtml .= '</ul>';
  }
?>
<?=$writersHtml?>
";

  // Recipient: registrant
  $to = $reg['guardian_email'];
  $subject_user = "Creative Chaos Registration Received (ID {$reg_id})";
  $body_user = "<h3>Thank you! Your registration was received.</h3>{$summary}<p>We will follow up with schedule and details. If you have questions, reply to this email.</p>";
  if($to){ cc_send_mail($to, $subject_user, $body_user); }

  // Admins
  $cfg = cc_env(); $admins = $cfg['admin_emails'] ?? [];
  if(is_array($admins)){
    foreach($admins as $a){
      if(!$a) continue;
      $subject_admin = "[CC] New Registration #{$reg_id}";
      $body_admin = "<h3>New Registration</h3>{$summary}<p><em>Sent automatically by the portal.</em></p>";
      cc_send_mail($a, $subject_admin, $body_admin);
    }
  }
}

</div>
<footer class="footer">
  <div>© <?=date('Y')?> Creative Chaos • Teays Valley West Middle School</div>
  <div class="small">Built for DreamHost shared hosting (PHP 8+, MySQL).</div>
</footer>
</body></html>

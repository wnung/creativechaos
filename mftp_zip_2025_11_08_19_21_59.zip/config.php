<?php
return [
  // DreamHost MySQL
  'db_host' => 'competition.creativechaoswrite.com',
  'db_name' => 'creativechaoscomp',
  'db_user' => 'creativechaos',
  'db_pass' => 'CreativeChaosWritingCompetition',

  // App URL (no trailing slash)
  'app_url' => 'https://registrations.creativechaoswrite.com',

   // Email (optional)
  'admin_emails' => ['williamnungester@gmail.com'],

  // Email (optional)
  'smtp' => [
    'enabled' => true,
    'host' => 'smtp.dreamhost.com',
    'port' => 587,
    'user' => 'noreply@creativechaoswrite.com',
    'pass' => 'CreativeChaosWritingCompetition123!',
    'from_email' => 'registration@creativechaoswrite.com',
    'from_name'  => 'Creative Chaos Writing Competition'
  ],

  // Google Sheets sync for registrations
  'google_sheets' => [
    'enabled' => false,
    'service_account_json' => __DIR__ . '/service_account.json',
    'sheet_id' => 'YOUR_SHEET_ID_HERE',
    'range' => 'Registrations!A1', // starting cell
    'value_input_option' => 'RAW'
  ],
];

# Creative Chaos Portal v2 — Installation (DreamHost Shared Hosting)

**Features**: Team/Open registration (7 writers included; $10 each additional), dynamic team roster, submissions, author showcase, admin dashboard, CSV export, secure downloads, optional Google Sheets sync.

## 1) Create a MySQL Database
- In the DreamHost Panel → **MySQL Databases**, create a DB, user, and note the **hostname**, **db name**, **user**, **password**.

## 2) Upload Files
- Upload the `creative-chaos-portal` folder to your site (e.g., `example.com/creative-chaos`). You can use DreamHost's WebFTP or SFTP.

## 3) Configure the App
- Copy `config.sample.php` → `config.php` and edit:
  - `db_host`, `db_name`, `db_user`, `db_pass`
  - `app_url` (e.g., `https://example.com/creative-chaos`)
- Optional: configure SMTP.

## 4) Initialize the Database
- Visit `https://yourdomain.com/creative-chaos/init_db.php` **once**.
- It will create tables and a first admin user. It will display the generated **password** (save it).
- Then delete or lock down `init_db.php` (optional but recommended).

## 5) Admin Login
- Go to `/admin/login.php`, sign in, and change the password.

## 6) Google Sheets (Optional)
- Create a Service Account and enable Google Sheets API. Download the JSON key.
- Share your Google Sheet with the service account **client_email** (Editor).
- Upload the JSON key as `/service_account.json` (or adjust the path in `config.php`).
- Set `'enabled' => true` and fill in your `sheet_id` and `range` under `google_sheets` in `config.php`.

**Registrations Sheet Column Order**
```
ID | Registration Type | Team Name | Student Name | Grade | School | Guardian Email | Category | Writer Count | Extra Writers | Fee | Created At
```

## 7) Security
- `uploads/.htaccess` blocks PHP execution and directory listing.
- Always keep `config.php` outside public repos.
- After setup, consider removing `init_db.php` or restricting access.

## 8) Cron / Backups (Optional)
- Use DreamHost Panel to schedule backups or export CSVs from the admin area.

## Change Admin Password
- After logging in, go to **Admin → Change Password**.

## Multi‑User Admin
- First admin created by `init_db.php` is `super`.
- Super admins can visit **Admin → Users** to add staff/super admins, enable/disable accounts, or reset passwords.
- Existing installs can run `/admin/migrate.php` once to add `role` and `is_active` columns.

## Remake Database (Danger)
- Super admins can use **Admin → Remake DB** to drop & recreate all tables and seed a new super admin.

## Pricing Rules
- Team: Base $100 includes up to 7 writers; $10 per additional writer.
- Open Class: $20 per writer; add multiple registrants in one form.

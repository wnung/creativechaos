<?php require_once __DIR__.'/../inc/auth.php'; cc_logout(); header('Location: login.php'); exit; ?>

<?php
require_once __DIR__.'/../inc/functions.php';
require_once __DIR__.'/../inc/auth.php';
require_once __DIR__.'/../inc/db.php';
$cfg=cc_env();
if (cc_is_logged_in()){ header('Location: dashboard.php'); exit; }
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  cc_csrf_check();
  if(cc_login($_POST['email'],$_POST['password'])){ header('Location: dashboard.php'); exit; }
  else $error='Invalid credentials';
}
?>
<!doctype html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login • Creative Chaos</title>
<link rel="stylesheet" href="<?=$cfg['app_url']?>/assets/styles.css">
  <link rel="stylesheet" href="/assets/css/cc-theme.css">
</head><body class="container">
<h2>Admin Login</h2>
<?php if($error) echo '<div class="alert">'.$error.'</div>'; ?>
<form method="post">
  <input type="hidden" name="csrf" value="<?=cc_csrf_token()?>">
  <label>Email</label><input name="email" type="email" required>
  <label>Password</label><input name="password" type="password" required>
  <button class="btn" type="submit">Sign In</button>
</form>
<p class="small"><a href="<?=$cfg['app_url']?>/">← Back to site</a></p>
</body></html>

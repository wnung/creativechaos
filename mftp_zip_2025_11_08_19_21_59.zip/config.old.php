<?php
// For convenience, this falls back to sample until you make a real config.php.
// Rename config.sample.php to config.php and edit values for production.
return include __DIR__.'/config.sample.php';
